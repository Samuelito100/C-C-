#ifndef MOLTIPLICAZIONE_H
#define MOLTIPLICAZIONE_H

int moltiplicazione(int a, int b, int c);

#endif