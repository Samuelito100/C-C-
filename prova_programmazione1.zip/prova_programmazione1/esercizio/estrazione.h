#ifndef ESTRAZIONE_H
#define ESTRAZIONE_H

int estrazione(int a, int b);

#endif